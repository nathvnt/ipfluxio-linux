#!/bin/bash
/usr/sbin/setcap cap_net_raw,cap_net_admin=eip "$1"